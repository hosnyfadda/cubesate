//$GPGGA,210302.552,5404.2675,N,00159.7569,W,1,10,4.00,100.0,M,50.0,M,,*7C
#include <SPI.h>
#include <SD.h>
File myFile;
class gps
{
  private:


  public:
String comingdata = "";
boolean string_is_full = false;
String signal = "$GPGGA";
String Hrs;
String Mins;
String Secs;
String LATint;
String LATdec;
String NS_direction;
String LONint;
String LONdec;
String EW_direction;
String fix_quality;
String Sats; //No. Of Sats
String ALT;

void getHrs()
{
  Hrs = comingdata.substring(7 , 9);
  
}
//_____________________________________________________
void getMins()
{
  Mins = comingdata.substring(9 , 11);
  
}
//_____________________________________________________
void getSecs()
{
  Secs = comingdata.substring(11 , 13);
  
}
//_____________________________________________________
void getLATint()
{
  LATint = comingdata.substring(18 , 20);
  int LATzero = LATint.indexOf('0');
  if (LATzero == 0)
   {
     LATint = LATint.substring(1);
   } 
}
//____________________________________________________

void getLATdec()
{
  LATdec = comingdata.substring(20 , 22); 
}
//____________________________________________________

void getNS_direction()
{
  NS_direction = comingdata.substring(28 , 29);
}
//____________________________________________________

void getLONint()
{
  LONint = comingdata.substring(30 , 35);
  int LONTzero = LONint.indexOf('0');
  if (LONTzero == 0) 
   {
     LONint = LONint.substring(1);
   } 
}
//____________________________________________________

void getLONdec()
{
  LONdec = comingdata.substring(33 , 35); 
}
//____________________________________________________

void getEW_direction()
{
  EW_direction = comingdata.substring(41 , 42);
}
//____________________________________________________
void getfix_quality(){
  fix_quality = comingdata.substring(43 , 44 );
}
//____________________________________________________
void getSat()
{
  Sats = comingdata.substring(45 , 47);
}
//____________________________________________________
void getALT()
{
  ALT = comingdata.substring(53 , 58); 
}
//____________________________________________________

bool readLocation()
{
  float floatHRS = Hrs.toFloat();
float floatLATdec = LATdec.toFloat();
float floatLONdec = LONdec.toFloat();
  A:
if (Serial.available())
    {
        char inChar = (char) Serial.read();
        comingdata += inChar;
        if (inChar == '\n') 
         {
           string_is_full = true;
         }
    }
    
 if (!string_is_full)
 {
  goto A;
 }
 
 if (string_is_full)
  {
     String BB = comingdata.substring(0 , 6);
       if (BB == signal)
       {
         getHrs();
         getMins();
         getSecs();
         getLATint();
         getLATdec();
         getNS_direction();
         getLONint();
         getLONdec();
         getEW_direction();
         getfix_quality();
         getSat();
         getALT();

   Serial.print("GPS message,");
   Serial.print(signal);
   Serial.print(",");
  ;
   Serial.print(int (floatHRS +2));
   Serial.print((":"));
   Serial.print(Mins);
   Serial.print((":"));
   Serial.print(Secs);
   Serial.print(F(","));
 
   Serial.print(LATint);
   Serial.print(("."));
   Serial.print(int (floatLATdec/0.06));
   Serial.print(F(","));
   
   Serial.print( NS_direction );
   Serial.print((","));
  
   Serial.print(LONint);
   Serial.print(F((".")));
   Serial.print(int (floatLONdec/0.06));
   Serial.print(F(","));

   Serial.print( EW_direction );
   Serial.print(F((",")));
   Serial.print(fix_quality);
   Serial.print(F((",")));
   Serial.print(Sats);
   Serial.print(F((",")));

   Serial.println(ALT);
   //Serial.println(F("/////////////////////"));  
   return true;  
  }
     comingdata = "";// after desplay, this empty the string
     string_is_full = false;//resting   
SD_Writing_Data();   

 }
 return false;
}
void SD_Writing_Data(){
    float floatHRS = Hrs.toFloat();
float floatLATdec = LATdec.toFloat();
float floatLONdec = LONdec.toFloat();
    if (!SD.begin(4)) {
    Serial.println(F("SD:0,"));
    } 
    else{
    myFile = SD.open("Data1.txt", FILE_WRITE);

  // if the file opened okay, write to it:
    if (myFile) {
    myFile.print(F("GPS:$GPGGA"));
      myFile.print(floatHRS +2);
            myFile.print(F(":"));
      myFile.print(Mins);
      myFile.print(F(":") );
      myFile.print(Secs );
 Serial.print(F(","));    
 myFile.print(LATint);
Serial.print(F("."));      
myFile.print(int (floatLATdec/0.06));
myFile.print(F(","));      
   myFile.print( NS_direction );
myFile.print(F(","));   
 myFile.print(LONint);
   myFile.print(F("."));
   myFile.print(int (floatLONdec/0.06));
   myFile.print(F(",")); 

   myFile.print( EW_direction );
   myFile.print(F(","));
   myFile.print(fix_quality);
   myFile.print(F(","));
   myFile.print(Sats);
   myFile.print(F(","));
    myFile.println(ALT);
    //myFile.println(F("**************************"));  
    
        
        
          
    // close the file:
    myFile.close();
    Serial.println(F("SD:1,"));
    }
    else {
    // if the file didn't open, print an error:
    Serial.println(F("SD:0,"));
    }
}
}
};
