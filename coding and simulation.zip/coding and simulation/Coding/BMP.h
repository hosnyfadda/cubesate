#include<Wire.h>
#include <SPI.h>
#include <SD.h>

class BMPsensor
{
  private:
  #define BMP  0x77
  #define AC1  0xAA
  #define AC2  0xAC
  #define AC3  0xAE
  #define AC4  0xB0
  #define AC5  0xB2
  #define AC6  0xB4
  #define B1  0xB6
  #define B2  0xB8
  #define MB  0xBA
  #define MC  0xBC
  #define MD  0xBE
  char oss;
  short slave,reg;
    long UT, UP, X1, X2, X3, T, B_3, B_5, B_6, P;
    unsigned long B_4 , B_7 ;

   
   public:
  short AC_1 = AC1;
  short AC_2 = AC2;
  short AC_3 = AC3;
  short AC_4 = AC4;
  short AC_5 = AC5;
  short AC_6 = AC6;
  short B_1 = B1;
  short B_2 = B2;
  short M_B = MB;
  short M_C = MC;
  short M_D = MD;

//_______________________________________________________________

int Read_data(int slave , int reg)
  { 
  short temp ;

    Wire.beginTransmission(slave);
    Wire.write(reg);
    Wire.endTransmission();
    Wire.requestFrom(slave , 2);
  if (Wire.available()==2);
    {
      temp = Wire.read();
      temp = temp<<8;
      temp = temp| ( Wire.read() );
      return temp ;
   } 
 }
//_________________________________________________________________

void BMPsetup() 
{
  Wire.begin();
  AC_1 = Read_data(BMP, AC1);
  AC_2 = Read_data(BMP, AC2);
  AC_3 = Read_data(BMP, AC3);
  AC_4 = Read_data(BMP, AC4);
  AC_5 = Read_data(BMP, AC5);
  AC_6 = Read_data(BMP, AC6);
  B_1 = Read_data(BMP, B1);
  B_2 = Read_data(BMP, B1);
  M_B = Read_data(BMP, MB);
  M_C = Read_data(BMP, MC);
  M_D = Read_data(BMP, MD);
}
//___________________________________________________________________

void Readdata()
{ 
      Wire.beginTransmission(BMP);
    Wire.write(0xf4);
    Wire.write(0x2E);
    Wire.endTransmission(BMP);

    delay(5);  // Can be 5 ms

    UT = Read_data(BMP , 0xF6);
    Wire.beginTransmission(BMP);
    Wire.write(0xf4);
    Wire.write( (0x34) | (oss<<6) );
    Wire.endTransmission(BMP);

    delay(5);  // Can be 5 ms

    Wire.beginTransmission(BMP);
    Wire.write(0xF6);
    Wire.endTransmission(BMP);
    Wire.requestFrom(BMP , 3);
  if (Wire.available()==3);
    {
      UP = Wire.read();
      UP = UP<<8;
      UP = UP | Wire.read();
      UP = UP<<8;
      UP = UP | Wire.read();
      UP = UP>>(8-oss);
    }
    
    Wire.beginTransmission(BMP);
    Wire.write(0xf4);
    Wire.write(0x2E);
    Wire.endTransmission(BMP);

    delay(4.5);  // Can be 5 ms

    UT = Read_data(BMP , 0xF6);

}

void SD_Writing_Data(){
  File myFile ;
    if (!SD.begin(4)) {
    Serial.println(F("SD:0,"));
    }
    else{ 
    myFile = SD.open("Data1.txt", FILE_WRITE);

  // if the file opened okay, write to it:
    if (myFile) {
    myFile.print(F("BMP: TEMP : "));
    myFile.print(T);
    myFile.print(F(" DegC      PRESS : "));
    myFile.print(P);
    myFile.println(F(" Pa ")); 
   
    
       
        
          
    // close the file:
    myFile.close();
    Serial.println(F("SD:1,"));
    }
    else {
    // if the file didn't open, print an error:
    Serial.println(F("SD:0,"));
    }}
}
//___________________________________________________________________

void showdata()
{
  long Pressure=P;
  
    X1 =   ( (UT - AC_6) * AC_5  ) / pow(2,15);
    X2 = ( M_C * pow(2,11) ) / (X1 + M_D);
    B_5 = X1 + X2 ;
    T = ( B_5+8 ) / pow(2,4);
 
  B_6 = B_5 - 4000 ;
    X1 = ( B_2 * ( (B_6 * B_6) / pow(2,12) ) ) / pow(2,11);
    X2 = ( AC_2*B_6/ pow(2,11) );
    X3 = X1+X2;
    B_3 = (((( AC1 * 4 ) + X3 )<<oss) + 2 ) / 4;
    X1 = (AC_3*B_6) / pow(2,13);
    X2 = ( B_1 * ( B_6*B_6 / pow(2,12) ) ) / pow(2,16);
    X3 = ( (X1+X2) + 2 ) /4;
    B_4 = ( AC_4 * (unsigned long)(X3 + 32768) ) / pow(2,15);
    B_7 = ( (unsigned long)UP - B_3 ) * (50000>>oss);

  if (B_7 < 0x80000000) 
    {
      P = (B_7 * 2 ) / B_4;
    }
  else
    {
      P = (B_7/B_4) * 2 ;
    }

    X1 = ( P / pow(2,8) ) * ( P / pow(2,8) );
    X1 = (X1 *3038) / pow(2,16);
    X2 = (-7357 * P ) / pow(2,16);
    P = P +( (X1 + X2 + 3791 ) / pow(2,4) );
    Serial.print(F("BMP "));
   
    
    Serial.print( ((Pressure/100.0)+577.9 )*100);   // from hectopascals to bars 
    Serial.print(F(","));
    X1 =   ( (UT - AC_6) * AC_5  ) / pow(2,15);

    X2 = ( M_C * pow(2,11) ) / (X1 + M_D);

    B_5 = X1 + X2 ;

    T = ( B_5+8 ) / pow(2,4);
    Serial.println ( (T / 10)-0.2);
    
    SD_Writing_Data();
}


};
