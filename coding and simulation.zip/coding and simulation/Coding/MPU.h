#include<Wire.h>
#include <MPU6050.h>
MPU6050 M;
class MPU_6050{
  private:
  public:
  // Timers for time step "Integration"
    unsigned long timer = 0;
    float timeStep = 0.01;

    // Pitch, Roll and Yaw values
      float pitch = 0;
      float roll = 0;
      float yaw = 0;

void intialize_MPU(){
  Serial.println(F("Intialize mpu:"));
while(!M.begin(MPU6050_SCALE_2000DPS,MPU6050_RANGE_2G))
{
  Serial.println(F("MPU not found"));
  delay(500);}
  //DLPF
  M.setDLPFMode(MPU6050_DLPF_3);
}

void gyroscope_offsets(){
   M.setGyroOffsetX(155);
  M.setGyroOffsetY(15);
    M.setGyroOffsetZ(155);
}

void checkSettings(){
  Serial.print(F("sleep Mode: "));
  Serial.println(M.getSleepEnabled()?"Enabled" : "Disabled");
  Serial.print(F("Clock source: "));
  switch(M.getClockSource()){
    case MPU6050_CLOCK_KEEP_RESET:  Serial.println(F("stop the clock and keep the timing generator in reset"));break;
     case MPU6050_CLOCK_EXTERNAL_19MHZ:  Serial.println(F("PLL with external 19.2 MHZ reference "));break;
      case MPU6050_CLOCK_EXTERNAL_32KHZ:  Serial.println(F("PLL with external 32.768 KHZ reference"));break;
       case MPU6050_CLOCK_PLL_ZGYRO:  Serial.println(F("PLL with Z axis gyro reference"));break;
        case MPU6050_CLOCK_PLL_YGYRO:  Serial.println(F("PLL with Y axis gyro reference"));break;
         case MPU6050_CLOCK_PLL_XGYRO:  Serial.println(F("PLL with X axis gyro reference"));break;
          case MPU6050_CLOCK_INTERNAL_8MHZ:  Serial.println(F("Internal 8MHZ oscillator"));break;
  }
  Serial.println(F("Accelerometer: "));
  switch(M.getRange()){
  case MPU6050_RANGE_16G:  Serial.println(F("+/-16g"));break;
   case MPU6050_RANGE_8G:  Serial.println(F("+/-8g"));break;
    case MPU6050_RANGE_4G:  Serial.println(F("+/-4g"));break;
     case MPU6050_RANGE_2G:  Serial.println(F("+/-2g"));break;
}
 Serial.println(F("Accelerometer offsets: "));
 Serial.print(M.getAccelOffsetX());
  Serial.print(F("/"));
  Serial.print(M.getAccelOffsetY());
    Serial.print(F("/"));
   Serial.print(M.getAccelOffsetZ());
   
//gyro

    Serial.print(F("GYROscope: "));
  switch(M.getScale()){
  case MPU6050_SCALE_2000DPS:  Serial.println(F("2000DPS"));break;
   case MPU6050_SCALE_1000DPS:  Serial.println(F("1000DPS"));break;
    case MPU6050_SCALE_500DPS:  Serial.println(F("500DPS"));break;
     case MPU6050_SCALE_250DPS:  Serial.println(F("250DPS"));break;
  }
   Serial.println(F("GYro offsets: "));
 Serial.print(M.getGyroOffsetX());
  Serial.print(F("/"));
  Serial.print(M.getGyroOffsetY());
    Serial.print(F("/"));
   Serial.print(M.getGyroOffsetZ());
}
float read_showAccel_data(){
      timer = millis();

  Vector normAccel=M.readNormalizeAccel();
  //Serial.print(F("Xnorm="));
Serial.print(normAccel.XAxis);
Serial.print(F(","));
//Serial.print(F("Ynorm="));
Serial.print(-normAccel.YAxis);
Serial.print(F(","));
//Serial.print(F("Znorm=-"));
Serial.print(normAccel.ZAxis=normAccel.ZAxis-1.1);  // calibrated to maintain an error
Serial.print(F("."));
//Serial.println("//////////////");
delay(10);
return normAccel.XAxis;
return normAccel.YAxis;
return normAccel.ZAxis;

}


/////////////////////////////////////////Gyro////////////////////////////////

void read_showGyro_Angles_data()
{
  timer = millis();

  //Vector norm = M.readNormalizeGyro();
  //Serial.print("Gyro");
// Vector rawGyro=M.readRawGyro();
Vector normGyro=M.readNormalizeGyro();
/*Serial.print("Xraw=");           //  row values of the gyroscope(values without proccessing
Serial.print(rawGyro.XAxis);
Serial.print("Yraw=");
Serial.print(rawGyro.YAxis);
Serial.print("Zraw=");
Serial.print(rawGyro.ZAxis);*/

//Serial.print("Xnorm=");
//Serial.print(normGyro.XAxis);

//Serial.print("Ynorm=");
//Serial.print(normGyro.YAxis);

//Serial.print("Znorm=");
//Serial.print(normGyro.ZAxis);
delay(10);


  pitch = pitch + normGyro.YAxis * timeStep;
  roll = roll + normGyro.XAxis * timeStep;
  yaw = yaw + normGyro.ZAxis * timeStep;

  // Output 
  // Serial.print(" YAngle = ");
  // Serial.print(pitch=pitch*(180/M_PI));
  // Serial.print(" XAngle = ");
  // Serial.print(roll=roll*(180/M_PI));  
  // Serial.print(" ZAngle = ");
  // Serial.println(yaw=yaw*(180/M_PI));
  //Serial.print(F("Pitch: "));
  Serial.print(pitch*(180/M_PI));
  //Serial.print(F("Roll: "));
  Serial.print(F(","));
  Serial.print(roll*(180/M_PI));
  Serial.print(F(","));
  //Serial.print(F("Yaw: "));
  Serial.println(yaw*(180/M_PI));

  //Wait full timestep
  //delay((timeStep*1000) - (millis() - timer));
  
 //SD_Writing_Data();
}
 void SD_Writing_Data() {
  Vector normAccel = M.readNormalizeAccel();
      Vector normGyro = M.readNormalizeGyro();
      if (!SD.begin(4)) {
        File myFile;
        Serial.println(F("SD:0,"));
      }
      else {
                File myFile;

        myFile = SD.open("Data1.txt", FILE_WRITE);

        // if the file opened okay, write to it:
        if (myFile) {
          myFile.print(F("MPU: Accel : "));
          myFile.print(normAccel.XAxis);
          myFile.print(F(" , : "));
          myFile.print(normAccel.YAxis);
          myFile.println(F(" , "));
          myFile.print(normAccel.ZAxis);
          myFile.println(F(" , "));
 myFile.print(F("MPU: Gyro : "));
          myFile.print(normGyro.XAxis);
          myFile.print(F(" , "));
          myFile.print(normGyro.YAxis);
          myFile.println(F(" , "));
          myFile.print(normGyro.ZAxis);
         




          // close the file:
          myFile.close();
          Serial.println(F("SD:1,"));
        }
        else {
          // if the file didn't open, print an error:
          Serial.println(F("SD:0,"));
        }
      }
    }

};
