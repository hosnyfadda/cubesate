
 unsigned char RH_int=0,RH_dec=0,T_int=0,T_dec=0,sum=0;
    unsigned char pulse [80];
class DHT_11
{
   private:
int pin;


   public:
int expectPulse(bool lvl)
  {
    int count=0;
    while(digitalRead(pin)==lvl) count++;
    return count;
  
    }
void intialize(int PIN_input)
  {
    pin= PIN_input;
  }

void read_data()
  {
   
    pinMode(pin,OUTPUT);
    digitalWrite(pin,HIGH);
    delay(1000);
    digitalWrite(pin,LOW);
    delay(18);
    digitalWrite(pin,HIGH);
    delayMicroseconds(40);
    pinMode(pin,INPUT);
    if (digitalRead(pin)==LOW)
    {
      while(digitalRead(pin)==LOW)
      {
        //delayMicroseconds(80);
        }
        while(digitalRead(pin)==HIGH)
      {
        //delayMicroseconds(80);
        }
      }
      else
      {
        Serial.println (F("NOT RESPONDING"));
        return;
        }
for (int i=0; i<80;i++)
      pulse[i]=expectPulse(i%2);
for (int i=0; i<40;i++)
     {
      unsigned char lowCycle = pulse [i*2];
      unsigned char highCycle = pulse [(i*2)+1];
      if (i<8)
          {
            RH_int<<=1;
            if (highCycle>lowCycle) RH_int|=1;
          }
      if (i<16)
          {
            RH_dec<<=1;
            if (highCycle>lowCycle) RH_dec|=1;
          }
      if (i<24)
          {
            T_int<<=1;
            if (highCycle>lowCycle) T_int|=1;
           }
      if (i<32)
          {
            T_dec<<=1;
            if (highCycle>lowCycle) T_dec|=1;
           }
      if (i<40)
          {
            sum<<=1;
            if (highCycle>lowCycle) sum|=1;
            }
          }
     if(sum!= RH_int+RH_dec+T_int+T_dec) 
      {
         Serial.println(F("ERROR!"));
         delay(1000);
         }
          else 
         {
            Serial.print(F("DHT "));
              Serial.print(T_int); Serial.print(".");
            Serial.print(T_dec);
            Serial.print(F(","));
            Serial.print(RH_int); Serial.print(F("."));
            Serial.println(RH_dec);
            //Serial.println("---");
          
        SD_Writing_Data();
            
           }
        
      }
      void SD_Writing_Data(){
        File myFile;
    if (!SD.begin(4)) {
    Serial.println(F("SD:0,"));
    } 
    else{
    myFile = SD.open("Data1.txt", FILE_WRITE);

  // if the file opened okay, write to it:
    if (myFile) {
    myFile.print(F("DHT:R.H: "));
    myFile.print(RH_int);
    myFile.print(F("."));
    myFile.print(RH_dec);
    myFile.print (F(" %"));
    myFile.print(F("Temperature: "));
    myFile.print(T_int);
    myFile.print(F("."));
    myFile.print(T_dec);
    myFile.println (F(" C"));

   
    
       
        
          
    // close the file:
    myFile.close();
    Serial.println(F("SD:1,"));
    }
    else {
    // if the file didn't open, print an error:
    Serial.println(F("SD:0,"));
    }
}
}
  
};
